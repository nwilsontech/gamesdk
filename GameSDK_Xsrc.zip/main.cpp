//#define UNREAL
//#define GLEW_STATIC

//#include <GL/glew.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <iostream>
#include <string>
#include <vector>
#include <cstdio>

#include "GXEngine/gx_engine.h"

using namespace std;

int main(int argc,char **argv)
{
//    if (glewInit() != GLEW_OK) {
//        fprintf(stderr, "Failed to initialize GLEW\n");
//        return 1;
//    }
    if (argc>1)
    {
        printf("cool\n");
    }
    base_location = argv[0];
    std::cout << base_location << std::endl;
    RunEngine();
    FinEngine();
    return 0;
}

