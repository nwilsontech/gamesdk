#include "gx_menu.h"
#include "gx_document.h"

gx_menu::gx_menu(float x, float y, float width, float height)
{
    xpos = x;
    ypos = y;
    wpos = width;
    hpos = height;
    bdrop = QuikQuad(xpos,ypos,0,wpos,hpos);
}


void gx_menu::Draw(void)
{
    glScissor((int)xpos,(int)ypos+hpos,(int)wpos,(int)hpos);
    glEnable(GL_SCISSOR_TEST);
    glDisable(GL_TEXTURE_2D);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glPushMatrix();
    glLineWidth(3.0);
    glEnableClientState(GL_VERTEX_ARRAY);

    glColor4f(0.7,0.7,0.7,1.0);
    glVertexPointer(3, GL_FLOAT, 0,&bdrop);

    glDrawArrays(GL_QUADS, 0, 4);
    glColor4f(0.2,0.2,0.2,1.0);
    glDrawArrays(GL_LINE_LOOP, 0, 4);
    glPopMatrix();
    glDisableClientState(GL_VERTEX_ARRAY);
    glColor4f(1.0f,1.0f,1.0f,1.0f);
    glLineWidth(1.0f);
cout<<xpos<<", "<<ypos<<", "<<wpos<<", "<<hpos<<"\n";

//    glEnable(GL_SCISSOR_BOX);


    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glPushMatrix();



    for(int i = 0; i < (int)Items.size(); i++)
        {
            glColor4f(1.0f,1.0f,1.0f,1.0f);
            if (Items.at(i)->GetType()==1)
            {
                RectX *tmp = (RectX *)Items.at(i);
                tmp->Draw();
            }else if (Items.at(i)->GetType()==2)
            {
                RectXAdv *tmp = (RectXAdv *)Items.at(i);
                tmp->Draw();
            }else if (Items.at(i)->GetType()==3)
            {
                glColor3f(1,1,1);
                THealthBar *tmp = (THealthBar *)Items.at(i);
                tmp->Draw();
                tmp->SetValue(0);

            }else if (Items.at(i)->GetType()==_pr_type_health_bar_ex)
            {
                THealthBarEx *tmp = (THealthBarEx *)Items.at(i);
                tmp->Draw();
                tmp->SetValue(0);

            }
            else if(Items.at(i)->GetType()==_pr_type_caption)
            {
                GXCaption *tcap = (GXCaption *)Items.at(i);
                tcap->Draw();
            }else if(Items.at(i)->GetType()==_pr_type_graphic)
            {

                TGraphic *tcap = (TGraphic *)Items.at(i);

                tcap->Draw();

            }
            else if(Items.at(i)->GetType()==_pr_type_group)
            {
                TGroup *tcap = (TGroup *)Items.at(i);
                tcap->Draw();
            }

        }

    glPopMatrix();

    glDisable(GL_SCISSOR_TEST);
    glDisable(GL_TEXTURE_2D);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glPushMatrix();
    glLineWidth(3.0);
    glEnableClientState(GL_VERTEX_ARRAY);
    glVertexPointer(3, GL_FLOAT, 0,&bdrop);
    glColor4f(0.2,0.2,0.2,1.0);
    glDrawArrays(GL_LINE_LOOP, 0, 4);
    glPopMatrix();
    glDisableClientState(GL_VERTEX_ARRAY);
    glColor4f(1.0f,1.0f,1.0f,1.0f);
    glLineWidth(1.0f);


 //   glDisable(GL_SCISSOR_BOX);

}
int  gx_menu::GetType(void)
{
    return _pr_type_menu;
}
void gx_menu::MoveXY(int _x,int _y)
{
    unused(_x);
    unused(_y);
}
void gx_menu::Update(MouseState ms)
{
   unused(ms);
}
bool gx_menu::Inside()
{
    return false;
}

size_t gx_menu::AddMenuItem(TPrimative *item)
{
    Items.push_back(item);
    return Size();
}
size_t gx_menu::Size(void)
{
    return (Items.size());
}
int    gx_menu::GetIndex(void)
{
    return 0;

}
TPrimative *gx_menu::GetIndexP(void)
{
    return NULL;
}
