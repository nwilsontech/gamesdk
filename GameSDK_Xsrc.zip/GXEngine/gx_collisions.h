#ifndef GX_COLLISIONS_H
#define GX_COLLISIONS_H

#include "gx_types.h"

bool rectOverlap2(QuikQuad aA, Vec3 aOff, QuikQuad bB, Vec3 bOff);

#endif // GX_COLLISIONS_H
