#ifndef GX_VARIABLES_H
#define GX_VARIABLES_H
//NA
#define UNREAL 1

#endif // GX_VARIABLES_H
