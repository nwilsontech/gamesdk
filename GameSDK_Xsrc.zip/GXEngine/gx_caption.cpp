#include "gx_caption.h"


GXCaption::GXCaption(float xx, float yy, std::string text):TPrimative()
{
    x    = xx;
    y    = yy;
    Text = text;
    Color = TColorFloat(1.0f,1.0f,1.0f,1.0f);
}
GXCaption::~GXCaption()
{

}

void GXCaption::Draw(void)
{
    glColor4f(1.0f,1.0f,1.0f,1.0f);
    //glColor4f(Color.red,Color.green,Color.blue,Color.alpha);
    FontDraw((char *)Text.c_str(),x,y);
    glColor4f(1.0,1.0,1.0,1.0);
}

int GXCaption::GetType(void)
{
    return _pr_type_caption;
}

void GXCaption::MoveXY(int _x,int _y)
{
    x = _x;
    y = _y;
}

void GXCaption::Update(MouseState ms)
{
    unused(ms);
}

bool GXCaption::Inside()
{
return false;
}
void GXCaption::FontColor(TColorFloat c)
{
    Color = c;
}

void GXCaption::FontColor(unsigned int c)
{
    unused(c);
//    ColorGrid CG = glColor2Grid(c);
//    Color.red   = CG.col[0];
//    Color.green = CG.col[1];
//    Color.blue  = CG.col[2];
   // SetColor3f(CG.col[0],CG.col[1],CG.col[2]);
}
