//#include "../GXShader/Shader.h"
#include "gx_shader.h"
#include "gx_logical.h"

#define LXXX
#ifdef UNREAL
    #include <SDL2/SDL.h>
    #include <SDL2/SDL_opengl.h>
    #include <SDL2/SDL_thread.h>
#else
    #include <SDL/SDL.h>
#endif
#include "gx_sprite.h"
#include "gx_inputhandler.h"
#include "gx_collisions.h"
#include "gx_particle.h"
#include "gx_group.h"
extern TGraphic *Graph;
vector<TPrimative *> boxes;
extern bool done;
extern bool loaded;
extern SDL_GLContext  context;
extern SDL_Window    *hWindow;

extern ShaderProgram *shader;

extern GXSprite *nix;
extern GXSprite *xin;
extern GXSprite *flame;
extern GXTexture *wals;
extern GXSprite *xxx;
extern GXSprite *block;
extern GXEmitter Emitter;

extern vector<GXSprite *> CheckList;

void setOrtho(int width, int height,int s__x,int s__y)
{
       glViewport(s__x,s__y,width,height);
       glMatrixMode(GL_PROJECTION);
       glLoadIdentity();
       gluOrtho2D(s__x,width,height,s__y);
}


static int state = 0;


static void CheckDim(){

}



static void Update()
{
//    bool t = false;

//    if (TheInputHandler::Instance()->isKeyDown(SDL_SCANCODE_RIGHT))
//    {
//        nix->velocity.Set(1,-0,-0);
//    }
//    if (TheInputHandler::Instance()->isKeyDown(SDL_SCANCODE_LEFT))
//    {
//        nix->velocity.Set(-1,0,0);
//    }

}





int RenderScene(void *data)
{


    unused(data);

    while(!loaded)
    {
        SDL_Delay( 1 );
    }

    while(!done)
    {

    SDL_GL_MakeCurrent(hWindow,context);

    glClearColor(0.0, 0.0, 0.0, 1.0);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glDisable(GL_TEXTURE_2D);
    glViewport(0,0,window_w,window_h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0,window_w,window_h,0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
//#define EXTRA
#ifdef EXTRA
    glEnable( GL_LINE_SMOOTH );
    glEnable( GL_POLYGON_SMOOTH );
    glHint( GL_LINE_SMOOTH_HINT, GL_NICEST );
    glHint( GL_POLYGON_SMOOTH_HINT, GL_NICEST );
#endif

    glPushMatrix();

    static float cc = 0;
    static float sign = 1;
    static float angle = 0;
#ifdef LXXX
    for(int i = 0; i < (int)boxes.size(); i++)
        {
            glColor4f(1.0f,1.0f,1.0f,1.0f);
            if (boxes.at(i)->GetType()==1)
            {
                RectX *tmp = (RectX *)boxes.at(i);
                tmp->Draw();
            }else if (boxes.at(i)->GetType()==2)
            {
                RectXAdv *tmp = (RectXAdv *)boxes.at(i);
                tmp->Draw();
            }else if (boxes.at(i)->GetType()==3)
            {
                glColor3f(1,1,1);
                THealthBar *tmp = (THealthBar *)boxes.at(i);
                tmp->Draw();
                tmp->SetValue(cc);

            }else if (boxes.at(i)->GetType()==_pr_type_health_bar_ex)
            {
                THealthBarEx *tmp = (THealthBarEx *)boxes.at(i);
                tmp->Draw();
                tmp->SetValue(cc);

            }
            else if(boxes.at(i)->GetType()==_pr_type_caption)
            {
                GXCaption *tcap = (GXCaption *)boxes.at(i);
                tcap->Draw();
            }else if(boxes.at(i)->GetType()==_pr_type_graphic)
            {
                //shader->use();
           //     GLint loc;
              //  loc = glGetUniformLocation (shader->handle (), "edgefalloff");
              //  glUniform1f (loc, 0.75f);

//                loc = glGetUniformLocation(shader->handle(),"Scale");
//                glUniform1f(loc,0.25);
//                loc = glGetUniformLocation(shader->handle(),"LightPosition");
//                glUniform3f(loc,0,0,0);

                TGraphic *tcap = (TGraphic *)boxes.at(i);
                tcap->SetAngle(angle);
                tcap->Draw();
               // shader->unuse();
            }
            else if(boxes.at(i)->GetType()==_pr_type_group)
            {

                TGroup *tcap = (TGroup *)boxes.at(i);
                tcap->Draw();
            }
            else if(boxes.at(i)->GetType()==_pr_type_menu)
            {
                gx_menu *tcap = (gx_menu *)boxes.at(i);
                tcap->Draw();
            }

        }
#endif
        /** Point*/

//        if (keys[SDL_SCANCODE_RIGHT]){
//            nix->xyz.x++;
//        }
        /** */
    Update();

//    xxx->Update(SDL_GetTicks());
//    nix->Update(SDL_GetTicks());
//    xin->Update(SDL_GetTicks());
//    block->Draw();
//    for(int iii=0;iii<55;iii++){
//        xin->SetCoord((iii%5)*40,(iii/5)*45,0);
//        xin->idx=iii;
//        xin->adx = -1;
        //xin->Update(SDL_GetTicks());
       // xin->CalculateExtTex(iii);
//        xin->Draw();
   //}
//    Emitter.position = nix->xyz;
//    Emitter.position.y+=nix->dim.y;
//    Emitter.floor    = nix->xyz.y+nix->dim.y;

//    Emitter.Update(SDL_GetTicks());
  //  nix->Draw();

   // xxx->xyz = Vec3(50,100,0);
  //  xxx->Draw();

    //fprintf(stderr,"spr\\%d\n",nix->SC);
    cc+=sign;
    angle+=1.5f;

    if (angle>360)
    {
        angle=0;
    }
//    cout<<"\rAngle:"<<angle<<"\t";
//    fflush(stdout);
    if (cc>100||cc<0)
    {
        cc = ((cc>100&&cc>=0)&(!(cc<0))) ? 100 : 0;
        sign *= -1.0f;
    }
    glPopMatrix();
#ifdef UNREAL
    glMatrixMode(GL_MODELVIEW);
    //cout<<"t"<<endl;
    //glFlush();
    //SDL_GL_SwapBuffers();

    SDL_GL_SwapWindow(hWindow);
    SDL_GL_MakeCurrent(hWindow,NULL);

#else
    glFlush();
    SDL_GL_SwapBuffers();
#endif
    }
    SDL_Quit();

    exit(0);
    return 0;

}
