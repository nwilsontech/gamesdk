
#include "gx_primatives.h"

TPrimative::TPrimative():xz(0),yz(0)
{

}
TPrimative::~TPrimative()
{

}
