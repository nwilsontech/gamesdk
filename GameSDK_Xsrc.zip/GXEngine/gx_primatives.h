#ifndef GX_PRIMATIVES_H
#define GX_PRIMATIVES_H

#include <vector>
#include <string>
#include <GL/gl.h>
#include <GL/glu.h>
#include "gx_color.h"
#include "types.h"
#include "gx_types.h"
using std::string;
using std::vector;

typedef void (*UpdateCallback)(int *v,int size);

enum PRIMATIVE_TYPE
{
    _pr_type_none,
    _pr_type_rect,
    _pr_type_rect_adv,
    _pr_type_health_bar,
    _pr_type_caption,
    _pr_type_graphic,
    _pr_type_health_bar_ex,
    _pr_type_group,
    _pr_type_menu
};

typedef unsigned int uint32;

class TPrimative
{
public:
    TPrimative();
    virtual ~TPrimative();
public:
    virtual int GetType(void) = 0;
    virtual void Draw(void) = 0;
    virtual void MoveXY(int _x,int _y) = 0;
    virtual void Update(MouseState ms) = 0;
    virtual bool Inside() = 0;
public:
    int xz;
    int yz;
};



#endif // GX_PRIMATIVES_H
