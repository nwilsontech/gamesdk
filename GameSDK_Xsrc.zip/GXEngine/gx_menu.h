#ifndef GX_MENU_H
#define GX_MENU_H


#include "gx_primatives.h"
#include <vector>
#include <string>

using std::vector;


class gx_menu:public TPrimative
{
public: //ctor & dtor
    gx_menu(float x, float y, float width, float height);
public: //Virtuals
    virtual void Draw(void);
    virtual int  GetType(void);
    virtual void MoveXY(int _x,int _y);
    virtual void Update(MouseState ms);
    virtual bool Inside();
public: //Functional Operators
    size_t AddMenuItem(TPrimative *item);
    size_t Size(void);
    int    GetIndex(void);
    TPrimative *GetIndexP(void);
public:
    float xpos;
    float ypos;
    float wpos;
    float hpos;
public:
    vector<TPrimative *> Items;
public:
    QuikQuad bdrop;
};

#endif // GX_MENU_H
