#ifndef GX_ENGINE_H
#define GX_ENGINE_H

#include "gx_variables.h"
#include "gx_logical.h"
#include "gx_graphic.h"


void RunEngine(void);
void FinEngine(void);
#endif // GX_ENGINE_H
