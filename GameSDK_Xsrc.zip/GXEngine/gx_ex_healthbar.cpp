#include "gx_ex_healthbar.h"
#include <iostream>
#include "font.h"
using std::cout;
using std::endl;

#define RECTX(m,x,y,w,h)             glBegin(m);\
                                      glVertex2f(x,y);\
                                      glVertex2f(x+w,y);\
                                      glVertex2f(x+w,y+h);\
                                      glVertex2f(x,y+h);\
                                   glEnd()

THealthBarEx::THealthBarEx(std::string fn,float _x,float _y,float _w,float _h):TPrimative()
{
  //  cout << __PRETTY_FUNCTION__<< "\n\tBegin\n"<<endl;
    x          = _x;
    y          = _y;
    w          = _w;
    h          = _h;
    colors     = 1;
    SetMax(100);
    SetValue(100);
    xz = 0;
    yz = 0;
    slider_pos = w;
    tex = new GXTexture(fn);


}
void THealthBarEx::MoveXY(int _x,int _y)
{
    x = _x;
    y = _y;
}

void THealthBarEx::Update(MouseState ms)
{
    xz = ms.x;
    yz = ms.y;
    slider_pos = cur_value/100.0 * w;
}

bool THealthBarEx::Inside()
{
    if ((xz>=x)&&(xz<=(x+w))&&(yz>=y)&&(yz<=(y+h)))
        return true;
    return false;
}
/// Healthbar Draw Function

void THealthBarEx::Draw(void)
{
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glEnable(GL_TEXTURE_2D);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
    glBindTexture(GL_TEXTURE_2D,tex->texID);
    glColor4f(1,1,1,1);
    glPushMatrix();
    glTranslated(x,y,0);

    static float inw = (float)tex->width;
    float mxx = (w/inw)/(max_value/cur_value);
    glBegin(GL_QUADS);
       glTexCoord2f(0.0,1.0); glVertex2f(0.0,h);
       glTexCoord2f(mxx,1.0); glVertex2f((w*(cur_value/max_value)),h);
       glTexCoord2f(mxx,0.0); glVertex2f((w*(cur_value/max_value)),0);
       glTexCoord2f(0.0,0.0); glVertex2f(0,0);
    glEnd();
    glMatrixMode(GL_MODELVIEW);
    glPopMatrix();
    glColor4f(1.0f,1.0f,1.0f,1.0f);
    glDisable(GL_BLEND);
    glDisable(GL_TEXTURE_2D);
    glLineWidth(1.0);

}
int THealthBarEx::GetType(void)
{
    return _pr_type_health_bar_ex;
}
void THealthBarEx::SetMax(float M)
{
    max_value = M;
}

void THealthBarEx::SetValue(float V)
{
    if (V<=max_value)
        cur_value = V;
    else
        cur_value = max_value;
}
