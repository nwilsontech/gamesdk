#ifndef GX_GRAPHIC_H
#define GX_GRAPHIC_H

//#include "texture.h"
#include "gx_texture.h"
#include "gx_primatives.h"

class TGraphic : public TPrimative
{
public:
    TGraphic(string fn = "",float xx=0,float yy=0);
public:
    void SetClip(float cw,float ch);
public:
    virtual void Draw(void);
    virtual int  GetType(void);
    virtual void MoveXY(int _x,int _y);
    virtual void Update(MouseState ms);
    virtual bool Inside();
    void SetSize(float ww,float hh);
    void SetAngle(float angle);
    void CalculateExtTex(int index);
public:
    bool  rotating;
private:
    void DrawRotated(void);


public: //temp moved to public for testing
    float x;
    float y;
private:
    QuikQuad   qm;
    QuikTexMap tm;
    float w;
    float h;
    float _clipw;
    float _cliph;
    float _index;
    float theata;

    GXTexture *tex;
};

#endif // GX_GRAPHIC_H
