#ifndef GX_CAPTION_H
#define GX_CAPTION_H

#include "font.h"
#include "gx_color.h"

#include "gx_primatives.h"
#include <string>

using std::string;

class GXCaption:public TPrimative
{
public:
    GXCaption(float xx,float yy,string text);  // ctor
    ~GXCaption(); // dtor
public:
    virtual void Draw(void);
    virtual int  GetType(void);
    virtual void MoveXY(int _x,int _y);
    virtual void Update(MouseState ms);
    virtual bool Inside();
    void FontColor(TColorFloat c);
    void FontColor(unsigned int c);
public:
    string Text;
    float  x,y;
    TColorFloat Color;
};

#endif // GX_CAPTION_H
