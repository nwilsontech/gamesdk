#include "gx_group.h"
#include "gx_document.h"

TGroup::TGroup(std::string n,float tx,float ty):TPrimative()
{
    x = tx;
    y = ty;
    name = n;
}
void TGroup::Add(TPrimative *item)
{
    prims.push_back(item);
}

void TGroup::Draw(void)
{
    //cout<<"Elements:\t"<<prims.size()<<endl;

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glPushMatrix();

    for(int i = 0; i < (int)prims.size(); i++)
        {
            glColor4f(1.0f,1.0f,1.0f,1.0f);
            if (prims.at(i)->GetType()==1)
            {
                RectX *tmp = (RectX *)prims.at(i);
                tmp->Draw();
            }else if (prims.at(i)->GetType()==2)
            {
                RectXAdv *tmp = (RectXAdv *)prims.at(i);
                tmp->Draw();
            }else if (prims.at(i)->GetType()==3)
            {
                glColor3f(1,1,1);
                THealthBar *tmp = (THealthBar *)prims.at(i);
                tmp->Draw();
                tmp->SetValue(0);

            }else if (prims.at(i)->GetType()==_pr_type_health_bar_ex)
            {
                THealthBarEx *tmp = (THealthBarEx *)prims.at(i);
                tmp->Draw();
                tmp->SetValue(0);

            }
            else if(prims.at(i)->GetType()==_pr_type_caption)
            {
                GXCaption *tcap = (GXCaption *)prims.at(i);
                tcap->x+=x;
                tcap->y+=y;
                tcap->Draw();
                tcap->x-=x;
                tcap->y-=y;
            }else if(prims.at(i)->GetType()==_pr_type_graphic)
            {
                TGraphic *tcap = (TGraphic *)prims.at(i);
                tcap->x+=x;
                tcap->y+=y;
                tcap->Draw();
                tcap->x-=x;
                tcap->y-=y;
            }
            else if(prims.at(i)->GetType()==_pr_type_group)
            {
                TGroup *tcap = (TGroup *)prims.at(i);
                tcap->Draw();
            }

        }
    glPopMatrix();
}

int  TGroup::GetType(void)
{
     return _pr_type_group;
}

void TGroup::MoveXY(int _x,int _y)
{
    unused(_x);
    unused(_y);
}

void TGroup::Update(MouseState ms)
{
    unused(ms);
}

bool TGroup::Inside()
{
    return false;
}
