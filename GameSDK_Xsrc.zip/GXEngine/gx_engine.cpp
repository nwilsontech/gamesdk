#include <GL/glew.h>
#include "GXShader/Shader.h"
//#include "Glext.h"
#include "gx_variables.h"
#ifdef UNREAL
    #include <SDL2/SDL.h>
    #include <SDL2/SDL_opengl.h>
    #include <SDL2/SDL_thread.h>
#else
    #include <SDL/SDL.h>
#endif
#include <GL/gl.h>
#include <GL/glu.h>
#include <IL/il.h>
#include <IL/ilu.h>
#include <IL/ilut.h>
#include "gx_engine.h"
#include "gx_document.h"
#include "gx_sprite.h"
#include "gx_inputhandler.h"
#include "gx_particle.h"
//vector<TPrimative *> boxes;

extern vector<TPrimative *> boxes;
ShaderProgram *shader;
bool done   = false;
bool loaded = false;

SDL_Thread* thread;
SDL_GLContext  context;
SDL_Window    *hWindow;
SDL_mutex *pud;
GXSprite *nix;
GXSprite *xin;
GXSprite *xxx;
GXSprite *block;
GXTexture *wals;

GXCaption    *Caption;
//GXEmitter Emitter;

vector<GXSprite *> CheckList;
//GXSprite *flame; // 22x38




/* Call this instead of exit(), so we can clean up SDL: atexit() is evil. */
static void
quit(int rc)
{
   // ( thread );
    SDL_Quit();
    exit(rc);
}

void FinEngine(void)
{
    SDL_WaitThread(thread,NULL);
}

void RunEngine(void)
{

    ilInit();
    iluInit();
    ilutRenderer(ILUT_OPENGL);


    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "Couldn't initialize SDL video subsystem: %s\n", SDL_GetError());
        return;
    }
#ifdef UNREAL
    /* Test showing a message box with a parent window */

        //SDL_Event event;
        hWindow = SDL_CreateWindow("Game Test", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                                   window_w, window_h, SDL_WINDOW_OPENGL|SDL_WINDOW_SHOWN);


        SDL_GL_SetAttribute(SDL_GL_MULTISAMPLEBUFFERS, 1);
        SDL_GL_SetAttribute(SDL_GL_MULTISAMPLESAMPLES, 4);
        SDL_GL_SetAttribute(SDL_GL_ACCELERATED_VISUAL, 1);
        SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 24);
        SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
        glEnable(GL_MULTISAMPLE);

        context = SDL_GL_CreateContext(hWindow);
        // Has to be after context is created
        if (glewInit() != GLEW_OK) {
            fprintf(stderr, "Failed to initialize GLEW\n");
            return;
        }
        if (context==NULL)
        {
            printf("failed context\n");
            return;
        }
        if( SDL_GL_SetSwapInterval( 1 ) < 0 )
        {
            printf( "Warning: Unable to set VSync! SDL Error: %s\n", SDL_GetError() );
        }
//        SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_ERROR,
//                                 "Missing file",
//                                 "File is missing. Please reinstall the program.",
//                                 NULL);

        pud = SDL_CreateMutex();
        if (pud==NULL)
        {
            printf("error could not create mutex\n");

        }
        if (SDL_LockMutex(pud) == 0) {
          /* Do stuff while mutex is locked */
            SDL_UnlockMutex(pud);
        } else {
          fprintf(stderr, "Couldn't lock mutex\n");
        }

        thread = SDL_CreateThread(&RenderScene, "Render_Window", NULL);

#else
    atexit(SDL_Quit);
    SDL_Surface* screen = SDL_SetVideoMode(window_w, window_h, 24,
                                           SDL_HWSURFACE|SDL_DOUBLEBUF|SDL_OPENGL);
    if ( !screen ) { printf("Unable to set 640x480 video: %s\n", SDL_GetError());return; }
#endif
    VertexShader vertToon ("test.vert");
    FragmentShader fragToon ("test.frag");
    shader = new ShaderProgram ("test", vertToon, fragToon);

    FontInit();

/** Player Stuff **/
//#pragma message "This is Where the  Sprite Is Init " __line__
   //cout<<__PRETTY_FUNCTION__<<" Cool\n";
    Caption = new GXCaption(0,0,"POC Demo - by Nathaniel Wilson");
    boxes.push_back(Caption);
    LoadPrimativesFromXMLDocument("load.xml",boxes,loaded);

//    gx_menu *gm   = new gx_menu(150,150,100,200);
//    TGraphic *add = new TGraphic("bars/immortal.jpg",128,128);
//    add->x = 150;
//    add->y = 150;
//    gm->AddMenuItem(add);
//    boxes.push_back(gm);

    if (loaded==true)
    {
        std::cout<<"Loaded Primatives\n";
    }

    while (!done)
    {
        // message processing loop
        TheInputHandler::Instance()->update();
        SDL_Event event;
        while (SDL_PollEvent(&event))
        {
            // check for messages
            switch (event.type)
            {
                // exit if the window is closed
            case SDL_QUIT:
                done = true;
                break;

                // check for keypresses
            case SDL_KEYDOWN:
                {
                    // exit if ESCAPE is pressed
                    if (event.key.keysym.sym == SDLK_ESCAPE)
                        done = true;
                    break;
                }
            } // end switch

        } // end of message processing
    } // end main loop

#ifdef UNREAL
    quit(0);
#endif
    done = true;
}
