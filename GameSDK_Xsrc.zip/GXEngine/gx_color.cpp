#include "gx_color.h"
#include "gx_util.h"
#include <iostream>
TFloat GetColor(string name)
{
    //Makes every thing lowercase
    toLowerCaseSTD(name);
    if (ColorTable.find(name)!=ColorTable.end())
    {
        TFloat t = ColorTable[name];
        return t;
    }else
    {
        std::cout <<"UNKNOWN COLOR <"<<name<<">"<<std::endl;
        return TFloat(1.0,1.0,1.0);
    }
}
