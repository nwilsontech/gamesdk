#include "gx_console.h"


void GXConsoleDebug::UpdateKeyboard(SDL_Event event){
    if (enabled==false)
    {
        (*mod) = "";
        return;
    }

//   // SDL_EnableUNICODE( SDL_ENABLE );
//    if( event.type == SDL_KEYDOWN )
//    {
//        //Keep a copy of the current version of the string
//        std::string temp = (*mod);

//        //If the string less than maximum size
//        if( (int)mod->length() <= str_limit )
//        {
//            if (isprint((Uint8)event.key.keysym.unicode)){
//                str += (char)event.key.keysym.unicode ;

//            }

//        }

//        if( mod != temp )
//        {

//            text_input = str;

//        }

    // SDL_EnableUNICODE( SDL_DISABLE );
}
