#ifndef GX_UTIL_H
#define GX_UTIL_H
#include <iostream>
#include <string>
#include <cctype>
#include <algorithm>

void toLowerCaseSTD(std::string &str);

#endif // GX_UTIL_H
