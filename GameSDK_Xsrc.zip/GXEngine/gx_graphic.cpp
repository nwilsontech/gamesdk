
#include "gx_shader.h"
#include "gx_graphic.h"



#include <cmath>

#define _PI 3.1415926535897932384626433832795f


const GLchar *vSource =
        "void main() {"
        "gl_Position = gl_Vertex;"
        "}";


const GLchar *fSource =
        "void main() {"
        "gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );"
        "}";

TGraphic::TGraphic(string fn, float xx, float yy):TPrimative()
{
    tex      = new GXTexture(fn);
    qm       = QuikQuad(0,0,0,tex->width,tex->height);
    tm       = QuikTexMap(0.0,1.0,
                          1.0,1.0,
                          1.0,0.0,
                          0.0,0.0);

    x        = xx;
    y        = yy;
    w        = tex->width;
    h        = tex->height;
    _clipw   = w;
    _cliph   = h;
    _index   = 0;
    theata   = 0;
    rotating = false;
    ///** AWESOME **///

//    VertexShader vertToon ("circ.vert");
//    FragmentShader fragToon ("circ.frag");
//    shader = new ShaderProgram ("dimple", vertToon, fragToon);



}

void TGraphic::SetClip(float cw,float ch)
{
    _clipw = cw;
    _cliph = ch;
}

void TGraphic::Draw(void)
{
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glEnable(GL_TEXTURE_2D);
    glEnable(GL_BLEND);
    if (!((_clipw!=w)&&(_cliph!=h))){
        if (!rotating){
            CalculateExtTex(_index);
        }else
        {
            if (!((_clipw!=w/2)&&(_cliph!=h/2)))
            {
                CalculateExtTex(_index);
            }
        }

    }

    glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
    glBindTexture(GL_TEXTURE_2D,tex->texID);
    glColor4f(1,1,1,1);
    glPushMatrix();
    float x0 = 0.0f,y0 = 0.0f;
    if (rotating)
    {
        x0 = w/2;
        y0 = h/2;
    }
    glTranslated(x+x0,y+y0,0);
    if (rotating){
    glRotated(theata,0.0,0.0,1.0);}

    if (rotating){

        qm.SmallSet(-w/2, h/2,
                     w/2, h/2,
                     w/2,-h/2,
                    -w/2,-h/2);
    }else
    {

        qm.SmallSet(0, h,
                    w, h,
                    w, 0,
                    0, 0);
    }

    glEnableClientState(GL_VERTEX_ARRAY);
    glEnableClientState( GL_TEXTURE_COORD_ARRAY );
    glVertexPointer(3, GL_FLOAT, 0,&qm);
    glTexCoordPointer(2,GL_FLOAT, 0,&tm);
    glDrawArrays(GL_QUADS, 0, 4);
    glDisableClientState(GL_VERTEX_ARRAY);
    glDisableClientState(GL_TEXTURE_COORD_ARRAY);
    glPopMatrix();
    glColor4f(1.0f,1.0f,1.0f,1.0f);
    glDisable(GL_BLEND);
    glDisable(GL_TEXTURE_2D);
}

int  TGraphic::GetType(void)
{
    return _pr_type_graphic;
}

void TGraphic::MoveXY(int _x,int _y)
{
    unused(_x);unused(_y);
}

void TGraphic::Update(MouseState ms)
{
    unused(ms);
}

bool TGraphic::Inside()
{
    return false;
}
void TGraphic::SetSize(float ww,float hh)
{
    w = ww;
    h = hh;
    qm = QuikQuad(0,0,0,w,h);
}
void TGraphic::SetAngle(float angle)
{
    theata = angle;
}
void TGraphic::CalculateExtTex(int index)
{
    int  _tw = tex->width;
    int  _th = tex->height;

    float tDivX,tDivY;
    int eX = _tw/_clipw;
    tDivX = 1.0/(float)(_tw / _clipw);
    tDivY = 1.0/(float)(_th / _cliph);

    float cx =  (float)(index % (int)(eX))*tDivX;///(_tw / x);
    float cy =  (float)(index / (int)(eX))*tDivY;///((int)(_th / y));

    tm.LongSet(cx            ,cy+tDivY      ,
               cx+tDivX      ,cy+tDivY      ,
               cx+tDivX      ,cy,
               cx            ,cy);

}
